package com.SeatReservation.Model;

public enum SeatType {
    FIRSTCLASS,
    BALCONY,
    ECONOMY
}