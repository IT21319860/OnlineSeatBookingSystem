package com.SeatReservation.service;

import com.SeatReservation.Model.MyUser;
import com.SeatReservation.Model.booking;
import com.SeatReservation.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    public List<booking> getBookingHistory() {
        return bookingRepository.findAll(); // Fetch from the database
    }

    public boolean isSeatBooked(int seatNumber, LocalDate date) {
        return bookingRepository.existsBySeatNumberAndBookingDate(seatNumber, date);
    }

    public booking createBooking(int seatNumber, LocalDate bookingDate, MyUser user) {
        booking newBooking = new booking();
        newBooking.setSeatNumber(seatNumber);
        newBooking.setBookingDate(bookingDate);
        newBooking.setStatus("Booked");
        newBooking.setUser(user); // Ensure user is associated with the booking
        return bookingRepository.save(newBooking);
    }


    public void cancelBooking(Long bookingId) {
        booking existingBooking = bookingRepository.findById(bookingId).orElse(null);
        if (existingBooking != null) {
            existingBooking.setStatus("Cancelled"); // Update status to Cancelled
            bookingRepository.save(existingBooking); // Save the updated booking
        }
    }

    public List<booking> getBookingHistory(MyUser user) {
        return bookingRepository.findByUser(user);
    }

}
