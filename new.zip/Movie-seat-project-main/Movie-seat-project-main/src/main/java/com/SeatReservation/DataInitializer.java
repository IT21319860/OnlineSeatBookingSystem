package com.SeatReservation;

import com.SeatReservation.Model.Seat;
import com.SeatReservation.Model.MyUser;
import com.SeatReservation.Model.Role;
import com.SeatReservation.Model.SeatType;
import com.SeatReservation.repository.SeatRepository;
import com.SeatReservation.service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    private final SeatRepository seatRepository;
    private final UserService userService;

    public DataInitializer(SeatRepository seatRepository, UserService userService) {
        this.seatRepository = seatRepository;
        this.userService = userService;
    }


        @Override
        public void run(String... args) {
            if (seatRepository.count() == 0) { // Only initialize seats if none exist
                List<Seat> seats = new ArrayList<>();

                initializeFirstClassSeats(seats);
                initializeEconomyClassSeats(seats);
                initializeBalconyClassSeats(seats);

                seatRepository.saveAll(seats); // Save all initialized seats
            }
        }

        private void initializeFirstClassSeats(List<Seat> seats) {
            for (int i = 1; i <= 30; i++) {
                Seat seat = new Seat();
                seat.setSeatNumber(i);
                seat.setBooked(false);
                seat.setSeatType(SeatType.FIRSTCLASS); // Set to FIRST_CLASS
                seats.add(seat);
            }
        }

        private void initializeEconomyClassSeats(List<Seat> seats) {
            for (int i = 31; i <= 60; i++) {
                Seat seat = new Seat();
                seat.setSeatNumber(i);
                seat.setBooked(false);
                seat.setSeatType(SeatType.ECONOMY); // Set to ECONOMY
                seats.add(seat);
            }
        }

        private void initializeBalconyClassSeats(List<Seat> seats) {
            for (int i = 61; i <= 90; i++) {
                Seat seat = new Seat();
                seat.setSeatNumber(i);
                seat.setBooked(false);
                seat.setSeatType(SeatType.BALCONY); // Set to BALCONY
                seats.add(seat);
            }
        }
    }
