package com.SeatReservation.controller;

import com.SeatReservation.Model.Seat;
import com.SeatReservation.service.SeatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/seats")
public class SeatController {
    private final SeatService seatService;

    @Autowired
    public SeatController(SeatService seatService) {
        this.seatService = seatService;
    }

    @GetMapping("/available")
    public List<Seat> getAvailableSeats(@RequestParam("date") String date) {
        LocalDate bookingDate = LocalDate.parse(date);
        return seatService.getAvailableSeats(bookingDate);
    }
}
