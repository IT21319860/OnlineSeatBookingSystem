package com.SeatReservation;

import com.SeatReservation.Model.*;
import com.SeatReservation.repository.SeatPriceRepository;
import com.SeatReservation.repository.SeatRepository;
import com.SeatReservation.service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private SeatRepository seatRepository;

    @Autowired
    private SeatPriceRepository seatPriceRepository;

    private final UserService userService;

    public DataInitializer(SeatRepository seatRepository, UserService userService) {
        this.seatRepository = seatRepository;
        this.userService = userService;
    }

    @Override
    public void run(String... args) {
        // Initialize only if no data exists
        if (seatRepository.count() == 0 && seatPriceRepository.count() == 0) {
            initializeSeatPrices(); // Initialize seat prices first
            List<Seat> seats = new ArrayList<>();
            initializeSeats(seats); // Initialize seats and associate prices
            seatRepository.saveAll(seats); // Save all initialized seats
        }
    }

    private void initializeSeatPrices() {
        // Check if seat prices already exist to avoid duplicates
        if (seatPriceRepository.count() == 0) {
            // Insert seat prices for each seat type
            SeatPrice firstClassPrice = new SeatPrice(SeatType.FIRSTCLASS, 2500);
            SeatPrice balconyPrice = new SeatPrice(SeatType.BALCONY, 1500);
            SeatPrice economyPrice = new SeatPrice(SeatType.ECONOMY, 1000);

            seatPriceRepository.save(firstClassPrice);
            seatPriceRepository.save(balconyPrice);
            seatPriceRepository.save(economyPrice);
        }
    }

    private void initializeSeats(List<Seat> seats) {
        initializeFirstClassSeats(seats);
        initializeEconomyClassSeats(seats);
        initializeBalconyClassSeats(seats);
    }

    private void initializeFirstClassSeats(List<Seat> seats) {
        // Fetch the corresponding price for FIRSTCLASS seats
        SeatPrice firstClassPrice = seatPriceRepository.findBySeatType(SeatType.FIRSTCLASS);
        for (int i = 1; i <= 15; i++) {
            Seat seat = new Seat();
            seat.setSeatNumber(i);
            seat.setBooked(false);
            seat.setSeatType(SeatType.FIRSTCLASS);
            seat.setSeatPrice(firstClassPrice); // Link price
            seats.add(seat);
        }
    }

    private void initializeEconomyClassSeats(List<Seat> seats) {
        // Fetch the corresponding price for ECONOMY seats
        SeatPrice economyPrice = seatPriceRepository.findBySeatType(SeatType.ECONOMY);
        for (int i = 16; i <= 60; i++) {
            Seat seat = new Seat();
            seat.setSeatNumber(i);
            seat.setBooked(false);
            seat.setSeatType(SeatType.ECONOMY);
            seat.setSeatPrice(economyPrice); // Link price
            seats.add(seat);
        }
    }

    private void initializeBalconyClassSeats(List<Seat> seats) {
        // Fetch the corresponding price for BALCONY seats
        SeatPrice balconyPrice = seatPriceRepository.findBySeatType(SeatType.BALCONY);
        for (int i = 61; i <= 90; i++) {
            Seat seat = new Seat();
            seat.setSeatNumber(i);
            seat.setBooked(false);
            seat.setSeatType(SeatType.BALCONY);
            seat.setSeatPrice(balconyPrice); // Link price
            seats.add(seat);
        }
    }
}
