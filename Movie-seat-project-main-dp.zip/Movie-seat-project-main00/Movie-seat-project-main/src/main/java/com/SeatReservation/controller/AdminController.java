package com.SeatReservation.controller;

import com.SeatReservation.Model.MyUser;
import com.SeatReservation.Model.SeatPrice;
import com.SeatReservation.Model.booking;
import com.SeatReservation.repository.BookingRepository;
import com.SeatReservation.repository.UserRepository;
import com.SeatReservation.service.BookingService;
import com.SeatReservation.service.SeatPriceService;
import com.SeatReservation.service.UserService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;



import java.util.List;


@Controller
public class AdminController {

    @Autowired
    private UserRepository userRepository; // Inject your repository

    @Autowired
    private BookingService bookingService;

    @Autowired
    private UserService userService;


    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private SeatPriceService seatPriceService;

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @GetMapping("/admin/dashboard")
    public String adminDashboard(Model model) {

        // Get authenticated user's username
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Fetch the user entity from the database
        MyUser user = userRepository.findByUsername(username);
        if (user != null) {
            model.addAttribute("username", user.getUsername());
            model.addAttribute("sltId", user.getSltId()); // Add sltId to the model
        } else {
            // Handle the case where user is not found
            model.addAttribute("username", "Guest");
            model.addAttribute("sltId", "N/A");
        }

        // Fetch all bookings and total bookings
        List<booking> bookings = bookingService.getBookingHistory();
        int totalBookings = bookings.size();
        model.addAttribute("totalBookings", totalBookings);
        model.addAttribute("bookings", bookings);

        // Fetch all users and total users
        List<MyUser> users = userService.getAllUsers();
        int totalUsers = users.size();
        model.addAttribute("totalUsers", totalUsers);

        // Fetch seat prices
        List<SeatPrice> seatPrices = seatPriceService.getAllSeatPrices();
        model.addAttribute("seatPrices", seatPrices);

        // Detect new bookings (last 24 hours)
        List<booking> newBookings = bookingService.getNewBookings();
        model.addAttribute("newBookings", newBookings);

        // Detect new users (last 24 hours)
        List<MyUser> newUsers = userService.getNewUsers();
        model.addAttribute("newUsers", newUsers);

        // Fetch data for line graph
        List<Integer> dailyUserCounts = userService.getDailyUserCounts(); // Implement this method
        List<Integer> dailyBookingCounts = bookingService.getDailyBookingCounts(); // Implement this method
        model.addAttribute("dailyUserCounts", dailyUserCounts);
        model.addAttribute("dailyBookingCounts", dailyBookingCounts);

        return "admin/dashboard"; // Returns admin dashboard page
    }


    @DeleteMapping("/admin/cancel/{bookingId}")
    public String cancelBookingAdmin(@PathVariable Long bookingId) {
        bookingService.cancelBooking(bookingId);
        return "redirect:/admin/bookings";  // Redirect to bookings after canceling the
    }

    @GetMapping("/admin/bookings")
    public String viewBookings(Model model) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Fetch the user entity from the database
        MyUser user = userRepository.findByUsername(username);
        if (user != null) {
            model.addAttribute("username", user.getUsername());
            model.addAttribute("sltId", user.getSltId()); // Add sltId to the model
        } else {
            // Handle the case where user is not found
            model.addAttribute("username", "Guest");
            model.addAttribute("sltId", "N/A");
        }


        List<booking> bookings = bookingService.getBookingHistory();

        // Ensure bookings include user data
        model.addAttribute("bookings", bookings);

        return "admin/bookings"; // Returns the admin/bookings.html view
    }

    @GetMapping("/admin/users")
    public String getAllUsers(Model model) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Fetch the user entity from the database
        MyUser user = userRepository.findByUsername(username);
        if (user != null) {
            model.addAttribute("username", user.getUsername());
            model.addAttribute("sltId", user.getSltId()); // Add sltId to the model
        } else {
            // Handle the case where user is not found
            model.addAttribute("username", "Guest");
            model.addAttribute("sltId", "N/A");
        }


        List<MyUser> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "admin/users"; // Returns the admin/users.html view
    }

    @GetMapping("/admin/user/{id}")
    @ResponseBody
    public ResponseEntity<MyUser> getUserById(@PathVariable Long id) {
        MyUser user = userService.getUserById(id);
        if (user != null) {
            return new ResponseEntity<>(user, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        }
    }

    @PutMapping("/admin/user/update/{id}")
    @ResponseBody
    public ResponseEntity<String> updateUser(@PathVariable Long id, @RequestBody MyUser updatedUser) {
        MyUser existingUser = userService.getUserById(id);

        if (existingUser != null) {
            // Set updated fields
            existingUser.setUsername(updatedUser.getUsername());
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setTelephone(updatedUser.getTelephone());
            existingUser.setDepartment(updatedUser.getDepartment());
            existingUser.setRole(updatedUser.getRole());

            // Update password only if it's provided

            userService.updateUser(existingUser); // Save updated user
            return new ResponseEntity<>("User updated successfully", HttpStatus.OK);
        }

        return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
    }


}
