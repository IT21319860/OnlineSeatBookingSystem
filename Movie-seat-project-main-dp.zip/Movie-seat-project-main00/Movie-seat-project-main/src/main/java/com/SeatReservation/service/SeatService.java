package com.SeatReservation.service;

import com.SeatReservation.Model.Seat;
import com.SeatReservation.Model.booking;
import com.SeatReservation.repository.BookingRepository;
import com.SeatReservation.repository.SeatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SeatService {

    @Autowired
    private SeatRepository seatRepository;

    @Autowired
    private BookingRepository bookingRepository;

    public List<Seat> getSeatsWithBookingStatus(LocalDate bookingDate) {
        List<Seat> allSeats = seatRepository.findAll(); // Get all seats

        // Get the numbers of seats booked on the selected date
        List<Integer> bookedSeatNumbers = bookingRepository.findByBookingDate(bookingDate)
                .stream()
                .map(booking::getSeatNumber)
                .collect(Collectors.toList());

        // Mark seats as booked if they are in the bookedSeatNumbers list
        allSeats.forEach(seat -> {
            if (bookedSeatNumbers.contains(seat.getSeatNumber())) {
                seat.setBooked(true); // Assuming Seat has a 'booked' field
            } else {
                seat.setBooked(false);
            }
        });

        return allSeats;
    }


    public Seat bookSeat(Long seatId, String bookingDateString) {
        if (!isDateValid(bookingDateString)) {
            return null;
        }

        Seat seat = seatRepository.findById(seatId).orElse(null);
        if (seat != null && !seat.isBooked()) {
            seat.setBooked(true);
            seatRepository.save(seat);

            booking newBooking = new booking();
            newBooking.setSeatNumber(seat.getSeatNumber());
            newBooking.setBookingDate(LocalDate.parse(bookingDateString, DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            newBooking.setStatus("Booked");
            bookingRepository.save(newBooking);

            return seat;
        }
        return null;
    }

    public void releaseSeat(Long seatId) {
        Seat seat = seatRepository.findById(seatId).orElse(null);
        if (seat != null && seat.isBooked()) {
            seat.setBooked(false);
            seatRepository.save(seat);
        }
    }

    private boolean isDateValid(String dateString) {
        try {
            LocalDate bookingDate = LocalDate.parse(dateString, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            LocalDate today = LocalDate.now();
            return !bookingDate.isBefore(today);
        } catch (DateTimeParseException e) {
            return false;
        }
    }
}
