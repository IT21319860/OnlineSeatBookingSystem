package com.SeatReservation.Model;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;


@Entity
@Table(name = "bookings")
public class booking {  // Renamed to follow proper naming convention
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int seatNumber;

    @Column(nullable = false)
    private LocalDate bookingDate;

    @Column(nullable = false)
    private String status; // e.g., "Booked", "Cancelled"

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id", nullable = false)  // Ensuring a non-null reference to MyUser
    private MyUser user;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    // Getters and Setters
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now(); // Set the current timestamp
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public MyUser getUser() {
        return user;
    }

    public void setUser(MyUser user) {
        this.user = user;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}