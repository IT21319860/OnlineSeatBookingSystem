package com.SeatReservation.controller;

import com.SeatReservation.Model.MyUser;
import com.SeatReservation.Model.SeatPrice;
import com.SeatReservation.repository.SeatPriceRepository;
import com.SeatReservation.repository.UserRepository;
import com.SeatReservation.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.security.authentication.AuthenticationManager;

import java.util.List;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SeatPriceRepository seatPriceRepository;

    @Autowired
    private AuthenticationManager authenticationManager;



    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    @GetMapping("/login")
    public String login() {

        return "login"; // Returns login.html
    }

    @PostMapping("/login")
    public String login(@ModelAttribute("MyUser") MyUser form, Model model) {
        // Authenticate the user
        MyUser user = userService.authenticate(form.getUsername(), form.getPassword());

        if (user == null) {
            logger.error("User authentication failed for username: {}", form.getUsername());
            model.addAttribute("error", "Invalid login credentials.");
            return "login";  // Return to login page if authentication fails
        }

        logger.info("Authenticated User: {}", user.getUsername());

        // Mark attendance for the authenticated user


        model.addAttribute("user", user);
        return "redirect:/home";  // Redirect to dashboard after successful login
    }


    @GetMapping("/register")
    public String register() {
        return "register"; // Returns register.html
    }

    @PostMapping("/register")
    public String registerUser(MyUser user, Model model) {
        userService.registerUser(user);
        model.addAttribute("message", "User registered successfully! Please login.");
        return "redirect:/login"; // Redirect to login after registration
    }

    @GetMapping("/admin/login")
    public String showAdminLogin() {
        return "admin/login"; // Return the login form (admin/login.html)
    }

    // Mapping to process the login form submission
    @PostMapping("/admin/login")
    public String adminLogin() {
        // Process login here (Spring Security handles authentication automatically if configured)
        return "redirect:/admin/dashboard"; // Redirect to admin dashboard upon successful login
    }

    @GetMapping("/admin/register")
    public String adminRegister() {
        return "admin/register"; // Returns admin registration page (admin/register.html)
    }

    @PostMapping("/admin/register")
    public String registerAdmin(MyUser admin, Model model) {
        userService.registerAdmin(admin);
        model.addAttribute("message", "Admin registered successfully! Please login.");
        return "redirect:/admin/login"; // Redirect to admin login after registration
    }

    @GetMapping("/home")
    public String home(Model model) {
        // Get authenticated user's username
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Fetch the user entity from the database
        MyUser user = userRepository.findByUsername(username);
        if (user != null) {
            model.addAttribute("username", user.getUsername());
            model.addAttribute("sltId", user.getSltId()); // Add sltId to the model
        } else {
            // Handle the case where user is not found
            model.addAttribute("username", "Guest");
            model.addAttribute("sltId", "N/A");
        }

        // Fetch seat prices and add to model
        List<SeatPrice> seatPrices = seatPriceRepository.findAll();
        model.addAttribute("seatPrices", seatPrices);

        return "home"; // Return the Thymeleaf template name
    }


    }




