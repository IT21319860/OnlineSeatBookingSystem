package com.SeatReservation.service;

import com.SeatReservation.Model.SeatPrice;
import com.SeatReservation.repository.SeatPriceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SeatPriceService {

    @Autowired
    private SeatPriceRepository seatPriceRepository;

    public List<SeatPrice> getAllSeatPrices() {
        return seatPriceRepository.findAll();
    }
}
