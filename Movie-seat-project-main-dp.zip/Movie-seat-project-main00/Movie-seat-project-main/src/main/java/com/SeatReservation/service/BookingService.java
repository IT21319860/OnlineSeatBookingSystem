package com.SeatReservation.service;

import com.SeatReservation.Model.MyUser;
import com.SeatReservation.Model.booking;
import com.SeatReservation.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    public List<booking> getBookingHistory() {
        return bookingRepository.findAll(); // Fetch from the database
    }

    public List<booking> getNewBookings() {
        LocalDateTime yesterday = LocalDateTime.now().minusDays(1);
        return bookingRepository.findByCreatedAtAfter(yesterday);
    }

    public boolean isSeatBooked(int seatNumber, LocalDate date) {
        return bookingRepository.existsBySeatNumberAndBookingDate(seatNumber, date);
    }

    public booking createBooking(int seatNumber, LocalDate bookingDate, MyUser user) {
        booking newBooking = new booking();
        newBooking.setSeatNumber(seatNumber);
        newBooking.setBookingDate(bookingDate);
        newBooking.setStatus("Booked");
        newBooking.setUser(user); // Ensure user is associated with the booking
        return bookingRepository.save(newBooking);
    }


    public void cancelBooking(Long bookingId) {
        booking existingBooking = bookingRepository.findById(bookingId).orElse(null);
        if (existingBooking != null) {
            existingBooking.setStatus("Cancelled"); // Update status to Cancelled
            bookingRepository.save(existingBooking); // Save the updated booking
        }
    }

    public List<booking> getBookingHistory(MyUser user) {
        return bookingRepository.findByUser(user);
    }

    public List<booking> getAllBookingHistory() {
        return bookingRepository.findAll(); // Fetch all booking records from the database
    }

    public void cancelBookingAdmin(Long bookingId) {
        booking existingBooking = bookingRepository.findById(bookingId).orElse(null);
        if (existingBooking != null) {
            existingBooking.setStatus("Cancelled"); // Update status to Cancelled
            bookingRepository.save(existingBooking); // Save the updated booking
        }
    }

    public List<Integer> getDailyBookingCounts() {
        // Define the number of days to fetch
        int days = 7;
        LocalDate endDate = LocalDate.now();
        List<Integer> bookingCounts = new ArrayList<>();

        for (int i = 0; i < days; i++) {
            LocalDate date = endDate.minusDays(i);
            LocalDateTime startOfDay = date.atStartOfDay(); // Start of the day
            LocalDateTime endOfDay = date.atTime(23, 59, 59); // End of the day

            // Count bookings created on that date
            int count = bookingRepository.countByCreatedAt(startOfDay, endOfDay);
            bookingCounts.add(count);
        }
        Collections.reverse(bookingCounts); // Optional: Reverse to have the latest date first
        return bookingCounts;
    }
    public booking findById(Long id) {
        return bookingRepository.findById(id).orElse(null); // Returns the booking or null if not found
    }

}
