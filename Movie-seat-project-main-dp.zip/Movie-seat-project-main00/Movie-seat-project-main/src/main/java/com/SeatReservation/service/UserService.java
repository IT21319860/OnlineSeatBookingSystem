package com.SeatReservation.service;

import com.SeatReservation.Model.MyUser;
import com.SeatReservation.Model.Role;
import com.SeatReservation.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    // Register a regular user
    public MyUser registerUser(MyUser user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole(Role.USER); // Set role as USER
        return userRepository.save(user);
    }

    // Register an admin user
    public MyUser registerAdmin(MyUser admin) {
        admin.setPassword(passwordEncoder.encode(admin.getPassword()));
        admin.setRole(Role.ADMIN); // Set role as ADMIN
        return userRepository.save(admin);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        MyUser user = userRepository.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("User not found with username: " + username);
        }
        return user; // Ensure User implements UserDetails correctly
    }


    public MyUser findByUsername(String username) {
        MyUser user = userRepository.findByUsername(username);
        if (user != null) {
            System.out.println("User fetched from repository: " + user.getUsername());  // Debugging statement
        }
        return user;
    }

    public void updateUser(MyUser user) {
        // Only encrypt password if it has been changed and is not empty
        if (user.getPassword() != null && !user.getPassword().isEmpty()) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        } else {
            // Fetch the current user's existing password if password is not provided
            MyUser existingUser = userRepository.findByUsername(user.getUsername());
            if (existingUser != null) {
                user.setPassword(existingUser.getPassword()); // Set existing password if no new password is provided
            }
        }
        userRepository.save(user); // Save the updated user back to the database
    }


    public MyUser findByUsernameAndPassword(String username, String password) {
        return userRepository.findByUsername(username);
    }

    public List<MyUser> getAllUsers() {
        return userRepository.findAll();
    }

    public List<MyUser> getNewUsers() {
        LocalDateTime yesterday = LocalDateTime.now().minusDays(1);
        return userRepository.findByCreatedAtAfter(yesterday);
    }


    public MyUser getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }


    public MyUser authenticate(String username, String password) {
        MyUser user = userRepository.findByUsername(username);
        if (user != null && passwordEncoder.matches(password, user.getPassword())) {
            return user;
        }
        return null;
    }


    public List<Integer> getDailyUserCounts() {
        // Define the number of days to fetch
        int days = 7;
        LocalDate endDate = LocalDate.now();
        List<Integer> userCounts = new ArrayList<>();

        for (int i = 0; i < days; i++) {
            LocalDate date = endDate.minusDays(i);
            LocalDateTime startOfDay = date.atStartOfDay(); // Start of the day
            LocalDateTime endOfDay = date.atTime(23, 59, 59); // End of the day

            // Count users created on that date
            int count = userRepository.countByCreatedAt(startOfDay, endOfDay);
            userCounts.add(count);
        }
        Collections.reverse(userCounts); // Optional: Reverse to have the latest date first
        return userCounts;
    }

}