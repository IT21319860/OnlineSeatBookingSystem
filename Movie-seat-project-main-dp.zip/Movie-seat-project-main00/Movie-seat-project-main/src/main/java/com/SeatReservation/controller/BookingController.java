package com.SeatReservation.controller;

import com.SeatReservation.Model.MyUser;
import com.SeatReservation.Model.booking;
import com.SeatReservation.repository.UserRepository;
import com.SeatReservation.service.BookingService;
import com.SeatReservation.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/booking")
public class BookingController {

    private final BookingService bookingService;

    @Autowired
    private EmailService emailService;


    @Autowired
    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @GetMapping("/history")
    public List<booking> getBookingHistory() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        MyUser myUser = (MyUser) authentication.getPrincipal();
        return bookingService.getBookingHistory(myUser);
    }

    @GetMapping("/history/all")
    public List<booking> getAllBookingHistory() {
        return bookingService.getAllBookingHistory(); // Fetch all bookings
    }

    @GetMapping("/check/{seatNumber}")
    public boolean checkSeatAvailability(@PathVariable int seatNumber, @RequestParam("date") String date) {
        LocalDate bookingDate = LocalDate.parse(date);
        return !bookingService.isSeatBooked(seatNumber, bookingDate);
    }

    @PostMapping("/create")
    public booking createBooking(@RequestParam int seatNumber, @RequestParam("date") String date) {
        // Parse the date
        LocalDate bookingDate = LocalDate.parse(date);

        // Get the authenticated user from the security context
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        MyUser myUser = (MyUser) authentication.getPrincipal(); // Assuming your user object is MyUser

        // Pass seatNumber, bookingDate, and the user object to the service
        return bookingService.createBooking(seatNumber, bookingDate, myUser);
    }

    @DeleteMapping("/cancel/{bookingId}")
    public void cancelBooking(@PathVariable Long bookingId) {
        bookingService.cancelBooking(bookingId);
    }

    @DeleteMapping("/admin/cancel/{bookingId}")
    public ResponseEntity<?> cancelBookingAdmin(@PathVariable Long bookingId) {
        booking booking = bookingService.findById(bookingId);

        if (booking == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Booking not found");
        }

        MyUser user = booking.getUser(); // Assuming your booking has a reference to the user
        if (user != null && user.getEmail() != null) {
            bookingService.cancelBooking(bookingId); // Cancel the booking

            // Send cancellation email
            String userEmail = user.getEmail();
            String emailSubject = "Booking Cancellation Notification";
            String emailBody = "Dear " + user.getUsername() + ",\n\n" +
                    "Your seat booking with Booking ID " + bookingId + " has been cancelled by the admin.\n\n" +
                    "Best regards,\nSeat Reservation Team";

            emailService.sendEmail(userEmail, emailSubject, emailBody);
        }

        return ResponseEntity.ok("Booking cancelled and notification email sent.");
    }

}
