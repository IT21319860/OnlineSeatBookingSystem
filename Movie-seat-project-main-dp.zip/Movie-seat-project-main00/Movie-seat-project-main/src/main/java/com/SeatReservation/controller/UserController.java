package com.SeatReservation.controller;

import com.SeatReservation.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.SeatReservation.Model.MyUser;

import org.springframework.http.HttpStatus;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;;
import java.util.Arrays;

@Controller
public class UserController {

    @Autowired
    private UserService userService; // Ensure you have this service to interact with user data

    @GetMapping("/profile")
    public String viewProfile(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null && authentication.isAuthenticated() && !"anonymousUser".equals(authentication.getName())) {
            String username = authentication.getName();
            System.out.println("Authenticated Username: " + username);  // Debugging statement
            MyUser user = userService.findByUsername(username);

            if (user != null) {
                System.out.println("Fetched User Details: " + user.getUsername());  // Debugging statement
                model.addAttribute("user", user);  // Correctly pass user details to the view
                model.addAttribute("departments", Arrays.asList("IT", "Management", "HR", "Finance"));
                return "/profile";  // Return the profile page
            } else {
                System.out.println("User not found with username: " + username);  // Debugging statement
            }
        } else {
            System.out.println("User is not authenticated.");  // Debugging statement
        }
        return "redirect:/home";  // Redirect if user is not found or not authenticated
    }


    @PostMapping("/profile/update")
    @ResponseBody
    public ResponseEntity<String> updateProfile(@RequestBody MyUser updatedUser) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();

        MyUser currentUser = userService.findByUsername(currentUsername);

        if (currentUser != null) {
            // Debugging statements
            System.out.println("Updating user with details: " + updatedUser);
            System.out.println("Current user: " + currentUser);

            // Ensure all required fields are populated before saving
            if (updatedUser.getEmail() == null || updatedUser.getEmail().isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"status\":\"error\", \"message\":\"Email cannot be empty.\"}");
            }

            // Update fields
            currentUser.setEmail(updatedUser.getEmail());

            currentUser.setTelephone(updatedUser.getTelephone());
            currentUser.setDepartment(updatedUser.getDepartment());


            // Update password only if it has changed
            if (updatedUser.getPassword() != null && !updatedUser.getPassword().isEmpty() &&
                    !updatedUser.getPassword().equals(currentUser.getPassword())) {
                currentUser.setPassword(new BCryptPasswordEncoder().encode(updatedUser.getPassword())); // Ensure password is hashed
            }

            // Save the updated user
            userService.updateUser(currentUser);
            return ResponseEntity.ok("{\"status\":\"success\", \"message\":\"Profile updated successfully!\"}");
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"status\":\"error\", \"message\":\"User not found.\"}");
    }
    @GetMapping("/admin/profile")
    public String viewProfileAdmin(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null && authentication.isAuthenticated() && !"anonymousUser".equals(authentication.getName())) {
            String username = authentication.getName();
            System.out.println("Authenticated Username: " + username);  // Debugging statement
            MyUser user = userService.findByUsername(username);

            if (user != null) {
                System.out.println("Fetched User Details: " + user.getUsername());  // Debugging statement
                model.addAttribute("user", user);  // Correctly pass user details to the view
                model.addAttribute("departments", Arrays.asList("IT", "Management", "HR", "Finance"));
                return "/admin/profile";  // Return the profile page
            } else {
                System.out.println("User not found with username: " + username);  // Debugging statement
            }
        } else {
            System.out.println("User is not authenticated.");  // Debugging statement
        }
        return "redirect:/admin/dashboard";  // Redirect if user is not found or not authenticated
    }


    @PostMapping("/admin/profile/update")
    @ResponseBody
    public ResponseEntity<String> updateProfileAdmin(@RequestBody MyUser updatedUser) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();

        MyUser currentUser = userService.findByUsername(currentUsername);

        if (currentUser != null) {
            // Debugging statements
            System.out.println("Updating user with details: " + updatedUser);
            System.out.println("Current user: " + currentUser);

            // Ensure all required fields are populated before saving
            if (updatedUser.getEmail() == null || updatedUser.getEmail().isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"status\":\"error\", \"message\":\"Email cannot be empty.\"}");
            }

            // Update fields
            currentUser.setEmail(updatedUser.getEmail());

            currentUser.setTelephone(updatedUser.getTelephone());
            currentUser.setDepartment(updatedUser.getDepartment());


            // Update password only if it has changed
            if (updatedUser.getPassword() != null && !updatedUser.getPassword().isEmpty() &&
                    !updatedUser.getPassword().equals(currentUser.getPassword())) {
                currentUser.setPassword(new BCryptPasswordEncoder().encode(updatedUser.getPassword())); // Ensure password is hashed
            }

            // Save the updated user
            userService.updateUser(currentUser);
            return ResponseEntity.ok("{\"status\":\"success\", \"message\":\"Profile updated successfully!\"}");
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"status\":\"error\", \"message\":\"User not found.\"}");
    }

}