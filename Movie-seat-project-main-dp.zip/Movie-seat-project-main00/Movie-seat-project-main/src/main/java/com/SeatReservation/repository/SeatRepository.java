package com.SeatReservation.repository;


import com.SeatReservation.Model.Seat;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SeatRepository extends JpaRepository<Seat, Long> {
    List<Seat> findByBooked(boolean booked);


}