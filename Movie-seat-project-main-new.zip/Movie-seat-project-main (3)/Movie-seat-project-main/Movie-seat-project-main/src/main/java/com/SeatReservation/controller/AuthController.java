package com.SeatReservation.controller;

import com.SeatReservation.Model.MyUser;
import com.SeatReservation.repository.UserRepository;
import com.SeatReservation.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.security.authentication.AuthenticationManager;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;


    @Autowired
    private AuthenticationManager authenticationManager;

    @GetMapping("/login")
    public String login() {
        return "login"; // Returns login.html
    }

    @GetMapping("/register")
    public String register() {
        return "register"; // Returns register.html
    }

    @PostMapping("/register")
    public String registerUser(MyUser user, Model model) {
        userService.registerUser(user);
        model.addAttribute("message", "User registered successfully! Please login.");
        return "redirect:/login"; // Redirect to login after registration
    }

    @GetMapping("/admin/login")
    public String adminLogin() {
        return "admin/login"; // Returns admin login page (admin/login.html)
    }

    @GetMapping("/admin/register")
    public String adminRegister() {
        return "admin/register"; // Returns admin registration page (admin/register.html)
    }

    @PostMapping("/admin/register")
    public String registerAdmin(MyUser admin, Model model) {
        userService.registerAdmin(admin);
        model.addAttribute("message", "Admin registered successfully! Please login.");
        return "redirect:/admin/login"; // Redirect to admin login after registration
    }

    @GetMapping("/home")
    public String home(Model model) {
        // Get authenticated user's username
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Fetch the user entity from the database
        MyUser user = userRepository.findByUsername(username);
        if (user != null) {
            model.addAttribute("username", user.getUsername());
            model.addAttribute("sltId", user.getSltId()); // Add sltId to the model
        } else {
            // Handle the case where user is not found
            model.addAttribute("username", "Guest");
            model.addAttribute("sltId", "N/A");
        }

        return "home"; // Return the Thymeleaf template name
    }

}

