package com.SeatReservation;

import com.SeatReservation.Model.Seat;
import com.SeatReservation.Model.MyUser;
import com.SeatReservation.Model.Role;
import com.SeatReservation.repository.SeatRepository;
import com.SeatReservation.service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    private final SeatRepository seatRepository;
    private final UserService userService;

    public DataInitializer(SeatRepository seatRepository, UserService userService) {
        this.seatRepository = seatRepository;
        this.userService = userService;
    }

    @Override
    public void run(String... args) {

        if (seatRepository.count() == 0) { // Only initialize seats if none exist
            List<Seat> seats = new ArrayList<>();
            for (int i = 1; i <= 10; i++) {
                Seat seat = new Seat();
                seat.setSeatNumber(i);
                seat.setBooked(false);
                seats.add(seat);
            }
            seatRepository.saveAll(seats);
        }


    }

}
