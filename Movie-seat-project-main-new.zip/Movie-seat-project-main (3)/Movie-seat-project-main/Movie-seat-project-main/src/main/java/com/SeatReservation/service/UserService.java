package com.SeatReservation.service;

import com.SeatReservation.Model.MyUser;
import com.SeatReservation.Model.Role;
import com.SeatReservation.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    // Register a regular user
    public MyUser registerUser(MyUser user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole(Role.USER); // Set role as USER
        return userRepository.save(user);
    }

    // Register an admin user
    public MyUser registerAdmin(MyUser admin) {
        admin.setPassword(passwordEncoder.encode(admin.getPassword()));
        admin.setRole(Role.ADMIN); // Set role as ADMIN
        return userRepository.save(admin);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        MyUser user = userRepository.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("User not found with username: " + username);
        }
        return user; // Ensure User implements UserDetails correctly
    }


    public MyUser findByUsername(String username) {
        MyUser user = userRepository.findByUsername(username);
        if (user != null) {
            System.out.println("User fetched from repository: " + user.getUsername());  // Debugging statement
        }
        return user;
    }

    public void updateUser(MyUser user) {
        // Only encrypt password if it has been changed and is not empty
        if (user.getPassword() != null && !user.getPassword().isEmpty()) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        } else {
            // Fetch the current user's existing password if password is not provided
            MyUser existingUser = userRepository.findByUsername(user.getUsername());
            if (existingUser != null) {
                user.setPassword(existingUser.getPassword()); // Set existing password if no new password is provided
            }
        }
        userRepository.save(user); // Save the updated user back to the database
    }


    public MyUser findByUsernameAndPassword(String username, String password) {
        return userRepository.findByUsername(username);
    }

    public List<MyUser> getAllUsers() {
        return userRepository.findAll();
    }

    public MyUser getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }


}