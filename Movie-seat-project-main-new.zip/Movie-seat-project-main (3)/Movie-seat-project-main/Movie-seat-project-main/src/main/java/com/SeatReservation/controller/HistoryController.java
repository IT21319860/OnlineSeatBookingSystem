package com.SeatReservation.controller;

import com.SeatReservation.Model.MyUser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.SeatReservation.Model.MyUser;
import com.SeatReservation.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;



@Controller
public class HistoryController {

    @Autowired
    private UserRepository userRepository; // Inject your repository

    @RequestMapping("/history")
    public String history(Model model) {
        // Get authenticated user's username
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Fetch the user entity from the database
        MyUser user = userRepository.findByUsername(username);
        if (user != null) {
            model.addAttribute("username", user.getUsername());
            model.addAttribute("sltId", user.getSltId()); // Add sltId to the model
        } else {
            // Handle the case where user is not found
            model.addAttribute("username", "Guest");
            model.addAttribute("sltId", "N/A");
        }

        return "history"; // Return the Thymeleaf template name for history page
    }
}
