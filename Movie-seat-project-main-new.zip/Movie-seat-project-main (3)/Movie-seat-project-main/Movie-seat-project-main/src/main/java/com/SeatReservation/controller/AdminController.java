package com.SeatReservation.controller;

import com.SeatReservation.Model.MyUser;
import com.SeatReservation.Model.booking;
import com.SeatReservation.service.BookingService;
import com.SeatReservation.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;;
import java.util.Arrays;

import java.util.Arrays;
import java.util.List;

@Controller
public class AdminController {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private UserService userService;

    @GetMapping("/admin/dashboard")
    public String adminDashboard(Model model) {
        List<booking> bookings = bookingService.getBookingHistory();
        model.addAttribute("bookings", bookings);
        return "admin/dashboard"; // Returns admin dashboard page (admin/dashboard.html)
    }

    @PostMapping("/admin/cancel/{id}")
    public String cancelBooking(@PathVariable Long id) {
        bookingService.cancelBooking(id);
        return "redirect:/admin/dashboard"; // Redirect to dashboard after canceling the booking
    }

    @GetMapping("/admin/bookings")
    public String viewBookings(Model model) {
        List<booking> bookings = bookingService.getBookingHistory();
        model.addAttribute("bookings", bookings);
        return "admin/bookings"; // Returns a detailed bookings view (admin/bookings.html)
    }

    @GetMapping("/admin/users")
    public String getAllUsers(Model model) {
        List<MyUser> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "admin/users"; // Returns the admin/users.html view
    }

    @GetMapping("/admin/user/{id}")
    @ResponseBody
    public ResponseEntity<MyUser> getUserById(@PathVariable Long id) {
        MyUser user = userService.getUserById(id);
        if (user != null) {
            return new ResponseEntity<>(user, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        }
    }
    @PutMapping("/admin/user/update/{id}")
    @ResponseBody
    public ResponseEntity<String> updateUser(@PathVariable Long id, @RequestBody MyUser updatedUser) {
        MyUser existingUser = userService.getUserById(id);

        if (existingUser != null) {
            // Set updated fields
            existingUser.setUsername(updatedUser.getUsername());
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setTelephone(updatedUser.getTelephone());
            existingUser.setDepartment(updatedUser.getDepartment());
            existingUser.setRole(updatedUser.getRole());

            // Update password only if it's provided

            userService.updateUser(existingUser); // Save updated user
            return new ResponseEntity<>("User updated successfully", HttpStatus.OK);
        }

        return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
    }




}
