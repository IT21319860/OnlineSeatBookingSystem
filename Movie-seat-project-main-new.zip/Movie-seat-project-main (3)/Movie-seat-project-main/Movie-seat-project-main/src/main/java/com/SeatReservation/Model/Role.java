package com.SeatReservation.Model;

public enum Role {
    USER, ADMIN
}
