package com.SeatReservation.controller;

import com.SeatReservation.Model.booking;
import com.SeatReservation.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/booking")
public class BookingController {

    private final BookingService bookingService;

    @Autowired
    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @GetMapping("/history")
    public List<booking> getBookingHistory() {
        return bookingService.getBookingHistory();
    }

    @GetMapping("/check/{seatNumber}")
    public boolean checkSeatAvailability(@PathVariable int seatNumber, @RequestParam("date") String date) {
        LocalDate bookingDate = LocalDate.parse(date);
        return !bookingService.isSeatBooked(seatNumber, bookingDate);
    }

    @PostMapping("/create")
    public booking createBooking(@RequestParam int seatNumber, @RequestParam("date") String date) {
        LocalDate bookingDate = LocalDate.parse(date);
        return bookingService.createBooking(seatNumber, bookingDate);
    }
    @DeleteMapping("/cancel/{bookingId}")
    public void cancelBooking(@PathVariable Long bookingId) {
        bookingService.cancelBooking(bookingId);
    }
}
