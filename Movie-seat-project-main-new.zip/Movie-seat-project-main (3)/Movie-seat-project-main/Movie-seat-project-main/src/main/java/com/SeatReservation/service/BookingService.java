package com.SeatReservation.service;

import com.SeatReservation.Model.booking;
import com.SeatReservation.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    public List<booking> getBookingHistory() {
        return bookingRepository.findAll(); // Fetch from the database
    }

    public boolean isSeatBooked(int seatNumber, LocalDate date) {
        return bookingRepository.existsBySeatNumberAndBookingDate(seatNumber, date);
    }

    public booking createBooking(int seatNumber, LocalDate bookingDate) {
        booking newBooking = new booking();
        newBooking.setSeatNumber(seatNumber);
        newBooking.setBookingDate(bookingDate);
        newBooking.setStatus("Booked"); // Set initial status
        return bookingRepository.save(newBooking); // Save to the database
    }

    public void cancelBooking(Long bookingId) {
        booking existingBooking = bookingRepository.findById(bookingId).orElse(null);
        if (existingBooking != null) {
            existingBooking.setStatus("Cancelled"); // Update status to Cancelled
            bookingRepository.save(existingBooking); // Save the updated booking
        }
    }
}
