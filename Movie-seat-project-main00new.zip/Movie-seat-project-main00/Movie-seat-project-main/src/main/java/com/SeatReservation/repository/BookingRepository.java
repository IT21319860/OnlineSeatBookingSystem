package com.SeatReservation.repository;

import com.SeatReservation.Model.MyUser;
import com.SeatReservation.Model.booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<booking, Long> {
    List<booking> findByBookingDate(LocalDate bookingDate);

    boolean existsBySeatNumberAndBookingDate(int seatNumber, LocalDate bookingDate);


    List<booking> findByUser(MyUser user);

    List<booking> findByCreatedAtAfter(LocalDateTime createdAt);

    // Add this method
    @Query("SELECT COUNT(b) FROM booking b WHERE b.createdAt >= :startOfDay AND b.createdAt < :endOfDay")
    int countByCreatedAt(@Param("startOfDay") LocalDateTime startOfDay, @Param("endOfDay") LocalDateTime endOfDay);
}