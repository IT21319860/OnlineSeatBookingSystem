package com.SeatReservation.repository;


import com.SeatReservation.Model.MyUser;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface UserRepository extends JpaRepository<MyUser, Long> {
    MyUser findByUsername(String username);

    // UserRepository
    List<MyUser> findByCreatedAtAfter(LocalDateTime createdAt);


    // Add this method
    @Query("SELECT COUNT(u) FROM MyUser u WHERE u.createdAt >= :startOfDay AND u.createdAt < :endOfDay")
    int countByCreatedAt(@Param("startOfDay") LocalDateTime startOfDay, @Param("endOfDay") LocalDateTime endOfDay);
}