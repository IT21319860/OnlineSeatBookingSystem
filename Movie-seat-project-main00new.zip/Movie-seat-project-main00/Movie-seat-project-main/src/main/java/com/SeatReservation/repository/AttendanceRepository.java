package com.SeatReservation.repository;

import com.SeatReservation.Model.Attendance;
import com.SeatReservation.Model.MyUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    List<Attendance> findByUser(MyUser user);

    List<Attendance> findByUserAndDate(MyUser user, LocalDate date);


}