package com.SeatReservation.repository;

import com.SeatReservation.Model.SeatPrice;
import com.SeatReservation.Model.SeatType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SeatPriceRepository extends JpaRepository<SeatPrice, Long> {
    SeatPrice findBySeatType(SeatType seatType); // Custom method to find price by seat type
}
