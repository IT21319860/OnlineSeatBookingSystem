package com.SeatReservation.controller;


import com.SeatReservation.Model.MyUser;
import com.SeatReservation.repository.UserRepository;
import com.SeatReservation.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class SeatBookingController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmailService emailService;

    @RequestMapping("/booking")
    public String booking(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        MyUser user = userRepository.findByUsername(username);

        if (user != null) {
            model.addAttribute("username", user.getUsername());
            model.addAttribute("sltId", user.getSltId());
            model.addAttribute("email", user.getEmail());
        } else {
            model.addAttribute("username", "Guest");
            model.addAttribute("sltId", "N/A");
            model.addAttribute("email", "");
        }

        return "booking";
    }


    @PostMapping("/api/email/send")
    public void sendEmail(@RequestParam String email, @RequestParam String seatNumber, @RequestParam String date) {
        try {
            emailService.sendBookingConfirmation(email, seatNumber, date);
        } catch (Exception e) {
            // Log the error or handle it as per your application needs
            System.err.println("Error sending email: " + e.getMessage());
        }
    }
}
