package com.SeatReservation.dto;

import org.springframework.web.bind.annotation.GetMapping;


public class HomePageInfo {
    private long availableSeats;
    private long totalBookings;

    public HomePageInfo(long availableSeats, long totalBookings) {
        this.availableSeats = availableSeats;
        this.totalBookings = totalBookings;
    }

    public long getAvailableSeats() {
        return availableSeats;
    }

    public long getTotalBookings() {
        return totalBookings;
    }
}