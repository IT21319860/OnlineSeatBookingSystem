package com.SeatReservation.service;

import com.SeatReservation.Model.Attendance;
import com.SeatReservation.Model.MyUser;
import com.SeatReservation.repository.AttendanceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
@Transactional
public class AttendanceService {

    private static final Logger logger = LoggerFactory.getLogger(AttendanceService.class);

    @Autowired
    private AttendanceRepository attendanceRepository;

    public boolean markAttendance(MyUser user) {
        LocalDate today = LocalDate.now();
        logger.info("Attempting to mark attendance for user: {} on {}", user.getUsername(), today);

        // Check if attendance is already marked
        List<Attendance> existingAttendance = attendanceRepository.findByUserAndDate(user, today);
        logger.info("Existing attendance records for user {}: {}", user.getUsername(), existingAttendance.size());

        if (existingAttendance.isEmpty()) {
            Attendance attendance = new Attendance();
            attendance.setUser(user);
            attendance.setDate(today);
            attendance.setStatus("Present");  // Or any other status as needed

            attendanceRepository.save(attendance);
            logger.info("Attendance successfully marked for user: {} on {}", user.getUsername(), today);
            return true;
        } else {
            logger.warn("Attendance already marked for user: {} on {}", user.getUsername(), today);
            return false;
        }
    }

    // Fetch all attendance records
    public List<Attendance> getAllAttendance() {
        return attendanceRepository.findAll();
    }
}
